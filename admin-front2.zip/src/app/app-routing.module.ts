import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IndexComponent } from './index/index.component';
import { ProductsComponent } from './products/products.component';
import { CategoriesComponent } from './categories/categories.component';
import { DetailproductsComponent } from './products/detailproducts/detailproducts.component';

const routes: Routes = [
  {
    path:'',component:IndexComponent,
  },
  {
    path:'products',component:ProductsComponent
  },
  {
    path:'products/detailproducts/:id',component:DetailproductsComponent
  },
  {
    path:'category',component:CategoriesComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
