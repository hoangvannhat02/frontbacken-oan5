import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { IndexComponent } from './index/index.component';
import { ProductsComponent } from './products/products.component';
import { HeaderComponent } from './layout/header/header.component';
import { CategoriesComponent } from './categories/categories.component';
import { FormsModule } from '@angular/forms';
import { MatPaginatorModule } from '@angular/material/paginator';
import { NgxPaginationModule } from 'ngx-pagination';
import { ColorsComponent } from './colors/colors.component';
import { BrandsComponent } from './brands/brands.component';
import { SizesComponent } from './sizes/sizes.component';
import { SuppliersComponent } from './suppliers/suppliers.component';
import { ImportinvoicesComponent } from './importinvoices/importinvoices.component';
import { DetailproductsComponent } from './products/detailproducts/detailproducts.component';

@NgModule({
  declarations: [
    AppComponent,
    IndexComponent,
    ProductsComponent,
    HeaderComponent,
    CategoriesComponent,
    ColorsComponent,
    BrandsComponent,
    SizesComponent,
    SuppliersComponent,
    ImportinvoicesComponent,
    DetailproductsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    MatPaginatorModule,
    NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
