import { Component } from '@angular/core';

@Component({
  selector: 'app-importinvoices',
  templateUrl: './importinvoices.component.html',
  styleUrls: ['./importinvoices.component.css']
})
export class ImportinvoicesComponent {

}
