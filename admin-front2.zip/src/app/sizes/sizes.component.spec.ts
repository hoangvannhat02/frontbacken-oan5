import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SizesComponent } from './sizes.component';

describe('SizesComponent', () => {
  let component: SizesComponent;
  let fixture: ComponentFixture<SizesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SizesComponent]
    });
    fixture = TestBed.createComponent(SizesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
