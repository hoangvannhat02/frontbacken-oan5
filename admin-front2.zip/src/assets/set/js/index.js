$(document).ready(function () {
    $('.box-user').click(function () {
        $('.info-user').toggleClass("hidden");
    })
    $("#iconclose").click(function () {
        $('.showmodel').hide();
    })
})